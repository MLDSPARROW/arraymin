# ArrayMin

A Helper pip package to find the minimum of an array. 


